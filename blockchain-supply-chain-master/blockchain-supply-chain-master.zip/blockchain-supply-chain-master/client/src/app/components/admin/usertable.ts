export interface UserTable {
    Name: String;
    Location: String;
    EthAddress: String;
    Role: String;
}
