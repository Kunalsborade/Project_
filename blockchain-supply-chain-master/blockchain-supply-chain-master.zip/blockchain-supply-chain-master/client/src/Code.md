web3.padRight(web3.fromAscii('hello'), 34)

web3.toAscii('0x537570706c696572204163636f756e74')